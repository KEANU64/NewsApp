package com.poh.newsapp;

public class News {
    private String mTitle;
    private String mAuthor;
    private String mSection;
    private String mPublicationDate;
    private String mUrl;

    public News (String title, String author, String section, String date, String url) {
        mTitle = title;
        mAuthor = author;
        mSection = section;
        mPublicationDate = date;
        mUrl = url;
    }

    public String getTitle() {return  mTitle; }
    public String getAuthor() {return mAuthor; }
    public String getSection() {return mSection;}
    public String getmPublicationDate() { return mPublicationDate;};
    public String getUrl() {return mUrl; }

}

