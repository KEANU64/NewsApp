package com.poh.newsapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class NewsAdapter extends ArrayAdapter<News> {


    public NewsAdapter(MainActivity context, ArrayList<News> newsArticles) {
        super(context, 0, newsArticles);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        // Get the {@link Word} object located at this position in the list
        News currentNews = getItem(position);

        TextView titleView = (TextView) convertView.findViewById(R.id.publication_title);
        String title = currentNews.getTitle();
        titleView.setText(title);

        TextView authorView = (TextView) convertView.findViewById(R.id.publication_author);
        String author = currentNews.getAuthor();
        authorView.setText(author);

        // Create a new Date from publication date string
        String dateString = currentNews.getmPublicationDate();

        TextView dateView = (TextView) convertView.findViewById(R.id.date);
        String dateToDisplay = formatDate(dateString);
        dateView.setText(dateToDisplay);

        TextView sectionView = (TextView) convertView.findViewById(R.id.section);
        String section = currentNews.getSection();
        sectionView.setText(section);

        return convertView;
    }


    //Format date of news 2016-09-26T15:57:34Z -> 2016-09-26
    private String formatDate(String dateString) {
        return dateString.split("T")[0];
    }


}
