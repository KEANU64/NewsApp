package com.poh.newsapp;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;

import java.util.List;

public class NewsLoader extends AsyncTaskLoader<List<News>> {

    /** Tag for log messages */
    private static final String LOG_TAG = NewsLoader.class.getName();

    /** Query URL */
    private String mUrl;

//    Debug to confirm the loading does not redo when the device is rotated

    public NewsLoader(@NonNull Context context, String mUrl) {
        super(context);
        Log.d("Debug newsLoader", "Loading");
        this.mUrl = mUrl;
    }

    @Override
    protected void onStartLoading() {
        Log.d("Debug onStart", "Start of news Load");
        forceLoad();
    }

    @Override
    public List<News> loadInBackground() {
        Log.d("Debug", "Loading news in background");
        if (mUrl == null){
            return null;
        }
        List<News> newsArticles = QueryUtils.fetchNews(mUrl);
        return newsArticles;
    }

}
